<?php
$title = 'Vendor Assignment';
$keywords = '';
$desc = '';
$pageclass = 'demopg';
use App\Models\Job;
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Vendors Dashboard/ Zach HR</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>


    <div class="container">
        <section class="vender-assignment">

            <div id="tabs-container">
                <ul class="tabs-menu">
                    <li class="current"><a href="#tab-1">Jobs</a></li>
                    <li><a href="#tab-2">Clients</a></li>
                    <li><a href="#tab-3">Teams</a></li>
                    <li><a href="#tab-4">Candidates</a></li>
                    <li><a href="#tab-5">Submissions</a></li>
                </ul>
                <div class="tab">
                    <div id="tab-1" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Job Title</th>
                                        <th>Client Name</th>
                                        <th>Department</th>
                                        <th>Country</th>
                                        <th>Salary Range</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($job->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($job->title); ?></td>
                                            <td><?php echo e($job->clients->name); ?></td>
                                            <td><?php echo e($job->department); ?></td>
                                            <td><?php echo e($job->country); ?></td>
                                            <td><?php echo e($job->salary_range); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('job.details', $job->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a href="<?php echo e(route('job.submission', $job->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">Submission</a>
                                                        <a
                                                            href="<?php echo e(route('vendor.delete-assigned-job', ['job' => $job->id, 'vendor' => $vendor->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $jobs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                    <div id="tab-2" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Client Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th>Address</th>
                                        <th>No. of Jobs</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $no_of_jobs = Job::where('client_id', $client->id)->count(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($client->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->email); ?></td>
                                            <td><?php echo e($client->phone); ?></td>
                                            <td><?php echo e($client->address); ?></td>
                                            <td>
                                                <?php if(!empty($no_of_jobs)): ?>
                                                    <?php echo e($no_of_jobs); ?>

                                                <?php else: ?>
                                                    None
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('client.details', $client->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a
                                                            href="<?php echo e(route('vendor.delete-assigned-client', ['client' => $client->id, 'vendor' => $vendor->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $clients], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                    <div id="tab-3" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Company Name</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($team->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($team->name); ?></td>
                                            <td><?php echo e($team->email); ?></td>
                                            <td><?php echo e(Auth::user()->name); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('team.details', $team->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a
                                                            href="<?php echo e(route('vendor.delete-team-member', ['team' => $team->id, 'vendor' => $vendor->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $teams], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                    <div id="tab-4" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Candidate Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th>Country</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($candidate->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($candidate->first_name); ?> <?php echo e($candidate->last_name); ?></td>
                                            <td><?php echo e($candidate->email); ?></td>
                                            <td><?php echo e($candidate->phone); ?></td>
                                            <td><?php echo e($candidate->country); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('candidate.details', $candidate->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a
                                                            href="<?php echo e(route('vendor.delete-candidate', ['candidate' => $candidate->id, 'vendor' => $vendor->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $candidates], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                    <div id="tab-5" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Job Title</th>
                                        <th>Client</th>
                                        <th>Vendor</th>
                                        <th>Candidate</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">
                                                    <input type="checkbox" name="" value="<?php echo e($submission->id); ?>"
                                                        class="submission-checkbox">
                                                    <?php echo e($submission->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($submission->job->title); ?></td>
                                            <td><?php echo e($submission->client->name); ?></td>
                                            <?php if($submission->vendor_id == 1): ?>
                                                <td><?php echo e($submission->user->name); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($submission->vendor->first_name); ?>

                                                    <?php echo e($submission->vendor->last_name); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($submission->candidate->first_name); ?>

                                                <?php echo e($submission->candidate->last_name); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        
                                                        <a href="<?php echo e(route('submission.show', $submission->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/edit.png')); ?>">view</a>
                                                        
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Submission delete')): ?>
                                                            <a href="<?php echo e(route('submission.delete', $submission->id)); ?>"><img
                                                                    src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $submissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/vendor/assignment.blade.php ENDPATH**/ ?>