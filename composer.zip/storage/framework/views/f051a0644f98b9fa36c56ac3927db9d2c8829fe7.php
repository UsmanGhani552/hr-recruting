<?php
$title = 'Client Assisment';
$keywords = '';
$desc = '';
$pageclass = 'cleintasist';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard / Candidate Assignments</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vender-assignment">
        <div class="container">
            <div id="tabs-container">
                <ul class="tabs-menu">
                    <li class="current"><a href="#tab-1">Submissions</a></li>
                    
                </ul>
                <div class="tab">
                    <div id="tab-1" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Job Title</th>
                                        <th>Client</th>
                                        <th>Vendor</th>
                                        <th>Candidate</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">
                                                    <input type="checkbox" name="" value="<?php echo e($submission->id); ?>"
                                                        class="submission-checkbox">
                                                    <?php echo e($submission->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($submission->job->title); ?></td>
                                            <td><?php echo e($submission->client->name); ?></td>
                                            <?php if($submission->vendor_id == 1): ?>
                                                <td><?php echo e($submission->user->name); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($submission->vendor->first_name); ?>

                                                    <?php echo e($submission->vendor->last_name); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($submission->candidate->first_name); ?>

                                                <?php echo e($submission->candidate->last_name); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        
                                                        <a href="<?php echo e(route('submission.show', $submission->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/edit.png')); ?>">view</a>
                                                        
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Submission delete')): ?>
                                                            <a href="<?php echo e(route('submission.delete', $submission->id)); ?>"><img
                                                                    src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $submissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/candidate/assignment.blade.php ENDPATH**/ ?>