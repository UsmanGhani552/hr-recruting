<h1>Welcome to Hayword Reruiting</h1>
<p>Thank you for register</p>
<?php /**PATH D:\laragon\www\hr-recruting\resources\views/mail/vendor_welcome.blade.php ENDPATH**/ ?>