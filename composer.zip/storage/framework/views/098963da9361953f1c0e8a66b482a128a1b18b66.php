<header class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <div class="logo">
                    <a href="javascript:;"><img src="<?php echo e(asset('assets/images/logo.png')); ?>"></a>

                </div>
            </div>

            <div class="col-md-7">
                <ul class="menu">
                    <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Vendor access', 'Vendor create', 'Vendor edit', 'Vendor delete')): ?>
                        <li><a href="<?php echo e(route('vendor-dashboard')); ?>">Vendor</a></li>
                    <?php endif; ?>

                    <li><a href="<?php echo e(route('client')); ?>">Client</a></li>
                    <li><a href="<?php echo e(route('job')); ?>">Job</a></li>
                    <li><a href="<?php echo e(route('candidate')); ?>">Candidate</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Team access', 'Team create', 'Team edit', 'Team delete')): ?>
                    <li><a href="<?php echo e(route('team')); ?>">Team</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Folder access', 'Folder create', 'Folder edit', 'Folder delete')): ?>
                        <li><a href="<?php echo e(route('folder')); ?>">Folder</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(route('submissions')); ?>">Submissions</a></li>

                    
                </ul>
            </div>

            <div class="col-md-3">
                <ul class="userdata">
                    <li><a href="<?php echo e(route('dashboard')); ?>"><img src="<?php echo e(asset('assets/images/comment.png')); ?>"></a>
                    </li>

                    <li><a href="<?php echo e(route('dashboard')); ?>"><img
                                src="<?php echo e(asset('assets/images/notification.png')); ?>"></a></li>
                    <li><a href="<?php echo e(route('permission.index')); ?>"><img src="<?php echo e(asset('assets/images/Setting_4.png')); ?>"></a>
                    </li>

                    <li><a href="<?php echo e(route('dashboard')); ?>">
                            <span><img src="<?php echo e(asset('assets/images/Setting_4.png')); ?>"></span>
                            <h6><?php echo e(Auth::user()->name ?? ''); ?> <small><?php echo e(Auth::user()->user_type ?? ''); ?></small></h6>
                        </a>
                    </li>

                    <li><small><a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?> </a>
                        </small>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>

        </div>
    </div>
    </div>
</header>
<?php /**PATH D:\laragon\www\hr-recruting\resources\views/layout/header.blade.php ENDPATH**/ ?>