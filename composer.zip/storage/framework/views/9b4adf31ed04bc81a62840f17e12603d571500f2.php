<?php
$title = 'Vendor Invite';
$keywords = '';
$desc = '';
$pageclass = 'vinvitepg';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard/</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vendor_invite">
        <div class="container">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            <div class="row">
                <div class="col-md-4">
                    <h6>Vendors</h6>
                    <div class="outbox admorebox">
                        <form action="<?php echo e(route('vendor-send-email')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="sendinvit">
                                <div class="addemailmore">
                                    <label class="form-group">
                                        Email Address
                                        <input type="email" name="email[]" class="form-controll"
                                            placeholder="Enter email">
                                            <?php $__errorArgs = ['email.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <ul>
                                    <li><a href="javascript:;" class="addmore"><img
                                                src="<?php echo e(asset('assets/images/plus.png')); ?>"> Add More</a></li>
                                    <li>
                                        <a href="javascript:;" class="delete">- Remove</a>
                                    </li>
                                </ul>

                                <div class="form-group">
                                    <input type="submit" name="" value="Submit">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="col-md-8">
                    <h6>Vendors Invitations</h6>
                    <div class="outbox outbox2">
                        <table>
                            <thead>
                                <tr>
                                    <th>
                                        <label for="orderid">
                                            <input type="checkbox" name="" id="orderid">
                                            ID
                                        </label>
                                    </th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>
                                        <div class="mydropdown">
                                            <ul class="dropbtn icons">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                        </div>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $vendorInvitations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorInvitation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <label for="">
                                            <input type="checkbox" name="" id="">
                                            <?php echo e($loop->index + 1); ?>

                                        </label>
                                    </td>
                                    <td><?php echo e($vendorInvitation->email); ?></td>
                                    <td class="active"><?php echo e($vendorInvitation->status == 1 ? 'Active' : 'Pending'); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <ul class="dropbtn icons">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                            <div id="myDropdown" class="dropdown-content">
                                                <a href="<?php echo e(route('vendor-resend-email',$vendorInvitation->id)); ?>"><img
                                                        src="<?php echo e(asset('assets/images/eye.png')); ?>">Resend</a>
                                                <a href="<?php echo e(route('vendor-delete-invite',$vendorInvitation->id)); ?>"><img
                                                        src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <!-- <label class="showrow">
                                    Show rows
                                    <select>
                                        <option>5 items</option>
                                        <option>10 items</option>
                                        <option>20 items</option>
                                    </select>
                                    </label> -->
                            </div>
                            
                            <?php echo $__env->make('layout.pagination', ['paginator' => $vendorInvitations], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/vendor/invite.blade.php ENDPATH**/ ?>