<?php
$title = 'Vendor Assignment';
$keywords = '';
$desc = '';
$pageclass = 'demopg';
use App\Models\Job;
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Vendors Dashboard/ Zach HR</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vender-assignment">
        <div class="container">
            <div id="tabs-container">
                
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                      <a class="nav-link active" href="<?php echo e(route('permission.index')); ?>" aria-current="page">Permissions</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('role.index')); ?>">Roles</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('add-admin.index')); ?>">Users</a>
                    </li>
                  </ul>
                <div class="tab">
                    <div id="tab-1" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                    <li>
                                        <a class="cbtn" href="<?php echo e(route('permission.create')); ?>"><img
                                                src="<?php echo e(asset('assets/images/invite.png')); ?>">Add Permission</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($permission->name); ?>

                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('permission.edit', $permission->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/edit.png')); ?>">Edit</a>
                                                        <a href="<?php echo e(route('permission.destroy', $permission->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <?php echo $__env->make('layout.pagination', ['paginator' => $permissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/settings/permission/index.blade.php ENDPATH**/ ?>