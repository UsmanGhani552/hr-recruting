<?php
$title = 'Add Client';
$keywords = '';
$desc = '';
$pageclass = 'addclient';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Client / Edit New Client</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vendor_invite addclient">
        <div class="container">
            <form method="POST" action="<?php echo e(route('client.update', $client->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <input type="hidden" value="<?php echo e($client->id); ?>" id="client_id">
                    <div class="col-md-4">
                        <h6>Client</h6>
                        <div class="outbox admorebox">
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Client Name*
                                        <input type="text" name="name" class="form-controll"
                                            placeholder="Enter email/username" value="<?php echo e($client->name); ?>">
                                    </label>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Website
                                        <input type="text" name="website" class="form-controll"
                                            placeholder="Enter email/username" value="<?php echo e($client->website); ?>">
                                    </label>
                                    <?php $__errorArgs = ['webiste'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-group">
                                        LinkedIn Page
                                        <input type="text" name="linkedln_page" class="form-controll"
                                            placeholder="Enter you company name" value="<?php echo e($client->linkedln_page); ?>">
                                    </label>
                                    <?php $__errorArgs = ['linkedln_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Email
                                        <input type="email" name="email" class="form-controll"
                                            placeholder="Enter your Email" value="<?php echo e($client->email); ?>">
                                    </label>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Phone No
                                        <input type="tell" name="phone" class="form-controll" placeholder="Phone"
                                            value="<?php echo e($client->phone); ?>">
                                    </label>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Address*
                                        <select class="form-controll" name="address">
                                            <option value="<?php echo e($client->address); ?>"
                                                <?php echo e($client->address == 'Address 1' ? 'selected' : ''); ?>>Address 1</option>
                                            <option value="<?php echo e($client->address); ?>"
                                                <?php echo e($client->address == 'Address 2' ? 'selected' : ''); ?>>Address 2</option>
                                            <option value="<?php echo e($client->address); ?>"
                                                <?php echo e($client->address == 'Address 3' ? 'selected' : ''); ?>>Address 3</option>
                                            <option value="<?php echo e($client->address); ?>"
                                                <?php echo e($client->address == 'Address 4' ? 'selected' : ''); ?>>Address 4</option>
                                        </select>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        City*
                                        <select class="form-controll" name="city">
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->id); ?>"
                                                    <?php echo e($client->city_id == $city->id ? 'selected' : ''); ?>>
                                                    <?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        State*
                                        <select class="form-controll" name="state">
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($state->id); ?>"
                                                    <?php echo e($client->state_id == $state->id ? 'selected' : ''); ?>>
                                                    <?php echo e($state->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Country*
                                        <select class="form-controll" name="country">
                                            <option value="United States">United States</option>
                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </select>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Company Size
                                        <input type="text" name="company_size" class="form-controll"
                                            placeholder="Company Size" value="<?php echo e($client->company_size); ?>">
                                        <?php $__errorArgs = ['company_size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Industry
                                        <input type="text" name="industry" class="form-controll"
                                            placeholder="Company Size" value="<?php echo e($client->industry); ?>">
                                        <?php $__errorArgs = ['industry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Year Founded
                                        <input type="date" name="year_founded" class="form-controll"
                                            placeholder="Company Size" value="<?php echo e($client->year_founded); ?>">
                                        <?php $__errorArgs = ['year_founded'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-group">
                                        Status*
                                        <select class="form-controll" name="marital_status">
                                            <option value="married"
                                                <?php echo e($client->marital_status == 'married' ? 'selected' : ''); ?>>married
                                            </option>
                                            <option value="Single"
                                                <?php echo e($client->marital_status == 'Single' ? 'selected' : ''); ?>>Single</option>
                                        </select>
                                        <?php $__errorArgs = ['marital_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-12">
                                    <div class="file-hidden-list"></div>
                                    <label class="form-group">
                                        Upload Documents For Vendor
                                        <div class="uploadoc">
                                            
                                            <input type="file" name="vendor_documents[]" multiple>
                                            <?php $__errorArgs = ['vendor_documnets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-12">
                                    <div class="file-hidden-list2"></div>
                                    <label class="form-group">
                                        Upload All Documents (for Admin)
                                        <div class="uploadoc">
                                            
                                            <input type="file" name="admin_documents[]" multiple>
                                            <?php $__errorArgs = ['admin_documnets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </label>
                                </div>

                                <div class="form-group">
                                    <input type="submit" name="" value="Submit">
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-md-8">

                        <h6>Uploaded Documents for Vendors</h6>
                        <div class="outbox adclientbox">
                            <div class="file-list">
                            </div>
                        </div>
                        <br>
                        <br>

                        <h6>Uploaded Documents for Admin</h6>
                        <div class="outbox adclientbox">
                            <div class="file-list2">
                            </div>
                        </div>
                        <br>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row adclientsearch">
                                    <div class="col-md-6">
                                        <h6>Assign Vendors</h6>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="search" id="search-input" class="form-controll"
                                                placeholder="Search by name">
                                        </div>
                                    </div>
                                </div>
                                <div class="outbox outbox2">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>
                                                    <label for="orderid">
                                                        
                                                        ID
                                                    </label>
                                                </th>
                                                <th>Vendor Name</th>
                                            </tr>
                                        </thead>
                                        <tbody id="search-results">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            function fetchData(query = '') {
                let client_id = $('#client_id').val();
                $.ajax({
                    method: 'GET',
                    url: "<?php echo e(url('client/selected-vendors')); ?>" +"/"+ client_id,
                    data: {
                        query: query
                    },
                    success: function(response) {
                        // console.log(response);
                        let allVendors = response[0];
                        let selectedVendors = response[1];
                        var results = '';
                        $.each(allVendors, function(index, vendor) {
                            // var isChecked = selectedVendors.some(function(selected) {
                            //     return selected.vendor_id === vendor.id;
                            // });
                            let isChecked = false;
                            for(let i = 0 ; i < selectedVendors.length ; i++){
                                if(selectedVendors[i].vendor_id == vendor.id){
                                    isChecked = true;
                                    break;
                                }
                            }

                            results += '<tr>' +
                                '<td><label><input type="checkbox" name="vendor[]" value="' +
                                vendor.id + '" ' + (isChecked ? 'checked' : '') + '>' + vendor
                                .id + '</label></td>' +
                                '<td>' + vendor.first_name + ' ' + vendor.last_name + '</td>' +
                                '</tr>';
                        });

                        $('#search-results').html(results);
                    }
                });
            }
            fetchData();
            $('#search-input').on('input', function() {
                var query = $(this).val();
                fetchData(query);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/client/edit.blade.php ENDPATH**/ ?>