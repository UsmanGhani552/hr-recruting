<?php
$title = 'Vendor Register';
$keywords = '';
$desc = '';
$pageclass = 'register-page';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="vender_login">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <figure>
                        <img src="<?php echo e(asset('assets/images/register-img.png')); ?>">
                    </figure>
                </div>
                <div class="col-md-6">
                    <div class="box">
                        <h2>Vendor invite</h2>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
                            totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae</p>
                        <form method="POST" action="<?php echo e(route('vendor-store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-group">
                                        First Name
                                        <input type="text" name="first_name" class="form-controll"
                                            placeholder="Enter First Name">
                                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Last Name
                                        <input type="text" name="last_name" class="form-controll"
                                            placeholder="Enter Last Name">
                                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                </div>
                                <div class="col-md-12">
                                    <label class="form-group">
                                        Company Name
                                        <input type="text" name="company_name" class="form-controll"
                                            placeholder="Enter you company name">
                                        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>

                                </div>

                                <div class="col-md-6">
                                    <label class="form-group">
                                        Email
                                        <input type="email" name="email" class="form-controll"
                                            placeholder="Email Address">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Phone No
                                        <input type="tel" name="phone" class="form-controll"
                                            placeholder="000-000-000 ">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Password
                                        <input type="password" name="password" class="form-controll"
                                            placeholder="000-000-000 ">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        Confirm Password
                                        <input type="password" name="password_confirmation" class="form-controll"
                                            placeholder="000-000-000 ">
                                    </label>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-group">
                                        Home/Office
                                        <input type="tel" name="home" class="form-controll"
                                            placeholder="000-000-000 ">
                                            <?php $__errorArgs = ['home'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        State
                                        <select id="state-dropdown" class="form-controll select2" name="state">
                                            <option></option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value=<?php echo e($state->id); ?>><?php echo e($state->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-group">
                                        City
                                        <select id="city-dropdown" class="form-controll select2" name="city">
                                            
                                        </select>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input class="btn" type="submit" name="" value="Submit">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<style>
    .select2-container--default .select2-selection--single .select2-selection__placeholder {
        display: block;
        width: 100%;
        border: 1px solid #C1C7CD;
        height: 54px;
        border-radius: 10px;
        background: #EEEEEE;
        color: #9FA6B2;
        padding: 10px 10px;
        /* margin: 10px 0px; */
    }

    span.select2-selection.select2-selection--single.select2-selection--clearable {
        display: block;
        width: 100%;
        border: 1px solid #C1C7CD;
        height: 54px;
        border-radius: 10px;
        background: #EEEEEE;
        color: #9FA6B2;
        padding: 10px 10px;
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: #444;
        line-height: 28px;
        padding: 0px !important;
    }

    .select2-container--default .select2-selection--single {
        background-color: #fff;
        border: none !important;
        border-radius: 4px;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        display: none;
    }

    span.select2-selection.select2-selection--single {
        margin-bottom: 18px;
        margin-top: 3px;
    }
</style>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#state-dropdown').on('change', function () {
                var idState = this.value;
                console.log(idState);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('input[name="_token"]').val()
                    }
                });
                
                $("#city-dropdown").html('');
                $.ajax({
                    url: "<?php echo e(url('api/fetch-cities')); ?>",
                    type: "POST",
                    data: {
                        state_id: idState,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (res) {
                        $('#city-dropdown').html('<option value="">-- Select City --</option>');
                        $.each(res.cities, function (key, value) {
                            $("#city-dropdown").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                });
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/vendor/create.blade.php ENDPATH**/ ?>