<h1>Hayword recruiting is inviting you to register</h1>
<h4>Here is the registration link</h4>
<a href="<?php echo e(route('vendor-create')); ?>">Click here to register</a>
<?php /**PATH D:\laragon\www\hr-recruting\resources\views/mail.blade.php ENDPATH**/ ?>