<?php
$title = 'Team Assisment';
$keywords = '';
$desc = '';
$pageclass = 'cleintasist';
use App\Models\Job;
?>


<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard / Team Members Assignments/</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vender-assignment">
        <div class="container">
            <div id="tabs-container">
                <ul class="tabs-menu">
                    <li class="current"><a href="#tab-1">Clients</a></li>
                    <li><a href="#tab-2">Jobs</a></li>
                </ul>
                <div class="tab">
                    <div id="tab-1" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="">
                                                ID
                                            </label>
                                        </th>
                                        <th>Client Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Country</th>
                                        <th>Created at</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $no_of_jobs = Job::where('client_id', $client->id)->count(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($client->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->email); ?></td>
                                            <td><?php echo e($client->phone); ?></td>
                                            <td><?php echo e($client->address); ?></td>
                                            <td>
                                                <?php if(!empty($no_of_jobs)): ?>
                                                    <?php echo e($no_of_jobs); ?>

                                                <?php else: ?>
                                                    None
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('team.client.details',['team' => $team->id, 'client' => $client->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a href="<?php echo e(route('team.delete-assigned-client', ['client' => $client->id, 'team' => $team->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <ul class="pagination">
                                        <li><a href="javascript:;"><i class="fa fa-angle-left"></i></a></li>
                                        <li><a href="javascript:;">1</a></li>
                                        <li><a href="javascript:;">2</a></li>
                                        <li><a href="javascript:;">3</a></li>
                                        <li><a href="javascript:;">4</a></li>
                                        <li><a href="javascript:;"><i class="fa fa-angle-right"></i></a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div id="tab-2" class="tab-content">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-end">
                                <ul class="vendordash_invite">
                                    <li>
                                        <a class="cbtn" href="javascript:;"><img
                                                src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <br>
                        <div class="outbox outbox2">
                            <table>
                                <thead>
                                    <tr>
                                        <th>
                                            <label for="orderid">
                                                <input type="checkbox" name="" id="orderid">
                                                Order ID
                                            </label>
                                        </th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Company Name</th>
                                        <th>Status</th>
                                        <th>Created at</th>
                                        <th>
                                            <div class="mydropdown">
                                                <ul class="dropbtn icons">
                                                    <li></li>
                                                    <li></li>
                                                    <li></li>
                                                </ul>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <label for="">

                                                    <?php echo e($job->id); ?>

                                                </label>
                                            </td>
                                            <td><?php echo e($job->title); ?></td>
                                            <td><?php echo e($job->clients->name); ?></td>
                                            <td><?php echo e($job->department); ?></td>
                                            <td><?php echo e($job->country); ?></td>
                                            <td><?php echo e($job->salary_range); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <ul class="dropbtn icons">
                                                        <li></li>
                                                        <li></li>
                                                        <li></li>
                                                    </ul>
                                                    <div id="myDropdown" class="dropdown-content">
                                                        <a href="<?php echo e(route('team.job.details',['team' => $team->id, 'job' => $job->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                        <a href="<?php echo e(route('job.submission', $job->id)); ?>"><img
                                                                src="<?php echo e(asset('assets/images/eye.png')); ?>">Submission</a>
                                                        <a href="<?php echo e(route('team.delete-assigned-job', ['job' => $job->id, 'team' => $team->id])); ?>"><img
                                                                src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="showrow">
                                        Show rows
                                        <select>
                                            <option>5 items</option>
                                            <option>10 items</option>
                                            <option>20 items</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <ul class="pagination">
                                        <li><a href="javascript:;"><i class="fa fa-angle-left"></i></a></li>
                                        <li><a href="javascript:;">1</a></li>
                                        <li><a href="javascript:;">2</a></li>
                                        <li><a href="javascript:;">3</a></li>
                                        <li><a href="javascript:;">4</a></li>
                                        <li><a href="javascript:;"><i class="fa fa-angle-right"></i></a></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/team/assignment.blade.php ENDPATH**/ ?>