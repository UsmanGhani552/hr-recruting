<h1>Vendor Registered Successfully</h1>
<?php /**PATH D:\laragon\www\hr-recruting\resources\views/mail/admin_notify.blade.php ENDPATH**/ ?>