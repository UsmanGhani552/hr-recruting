<h1>Vendor Registered Successfully</h1>
