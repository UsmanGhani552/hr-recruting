@extends('layout.master')

@section('top_nav')
    @include('layout.header')
@endsection

@section('main_content')

@include('layout.footer')
@endsection


