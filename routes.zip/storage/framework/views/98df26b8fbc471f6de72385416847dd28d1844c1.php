<div class="col-md-6">
    <ul class="pagination">
        <?php if($paginator->onFirstPage()): ?>
            <li class="d-none"><span>&laquo;</span></li>
        <?php else: ?>
            <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
        <?php endif; ?>

        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <li class="<?php echo e(($paginator->currentPage() == $i) ? 'active' : ''); ?>">
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>

        <?php if($paginator->hasMorePages()): ?>
            <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
        <?php else: ?>
            <li class="d-none"><span>&raquo;</span></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH D:\laragon\www\hr-recruting\resources\views/layout/pagination.blade.php ENDPATH**/ ?>