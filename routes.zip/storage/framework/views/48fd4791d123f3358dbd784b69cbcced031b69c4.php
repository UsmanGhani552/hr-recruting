<footer class="footer">
	<div class="container">		
	</div>	
</footer><?php /**PATH D:\laragon\www\hr-recruting\resources\views/layout/footer.blade.php ENDPATH**/ ?>