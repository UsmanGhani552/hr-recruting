<?php
$title = 'Candidate Main';
$keywords = '';
$desc = '';
$pageclass = 'maincadidate';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard / Submission</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="venderdashboar">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    
                </div>
                <div class="col-md-6 text-end">
                    <ul class="vendordash_invite">
                        <li>
                            <a class="cbtn filter_brn" href="javascript:;"><img
                                    src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="filterform">
                <form action="<?php echo e(route('submissions')); ?>" method="get">

                    <div class="form-group">
                        <label class="form-group">
                            Status
                            <select class="form-controll" name="status">
                                <option disabled selected>Selct state</option>
                                <option value="1">Approved</option>
                                <option value="2">Pending</option>
                                <option value="3">Rejected</option>
                            </select>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-group">
                            Vendor
                            <select class="form-controll" name="vendor">
                                <option disabled selected>Select Vendor</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->first_name); ?> <?php echo e($vendor->last_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-group">
                            job
                            <select class="form-controll" name="job">
                                <option disabled selected>Select job</option>
                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($job->id); ?>"><?php echo e($job->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-group">
                            client
                            <select class="form-controll" name="client">
                                <option disabled selected>Select client</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-group">
                            candidate
                            <select class="form-controll" name="candidate">
                                <option disabled selected>Select candidate</option>
                                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($candidate->id); ?>"><?php echo e($candidate->first_name); ?> <?php echo e($candidate->last_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="created_at_to">To</label>
                        <input id="created_at_to" type="date" class="form-control" name="created_at_to" placeholder="" >
                    </div>

                    <div class="form-group">
                        <label for="created_at_from">From</label>
                        <input id="created_at_from" type="date" class="form-control" name="created_at_from" placeholder="" >
                    </div>

                    <div class="form_bottons">
                        <button class="cbtn" type="submit">Apply</button>
                        <button class="cbtn btnreset" id="reset-btn" type="reset">Reset</button>
                    </div>

                </form>
            </div>
            <br>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div id="sucess-asigment-msg"> </div>
            <div class="outbox outbox2">
                <table>
                    <thead>
                        <tr>
                            <th>
                                <label for="orderid">
                                    <input type="checkbox" name="" id="orderid">
                                    Order ID
                                </label>
                            </th>
                            <th>Job Title</th>
                            <th>Client Name</th>
                            <th>Vendor Name</th>
                            <th>Team Member</th>
                            <th>Candidate Name</th>
                            <th>Vendor Commision</th>
                            <?php if(Auth::user()->id == 1): ?>
                                <th>Admin Commision</th>
                            <?php endif; ?>
                            <th>Created At</th>
                            <th>Completed At</th>
                            <th>Status</th>

                            <th>
                                <div class="mydropdown">
                                    <ul class="dropbtn icons">
                                        
                                        Actions
                                    </ul>

                                </div>
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Submission access')): ?>
                            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <label for="">
                                            <input type="checkbox" name="" value="<?php echo e($submission->id); ?>"
                                                class="submission-checkbox">
                                            <?php echo e($submission->id); ?>

                                        </label>
                                    </td>
                                    <td><?php echo e($submission->job->title); ?></td>
                                    <td><?php echo e($submission->client->name); ?></td>
                                    <?php if($submission->vendor_id == 1): ?>
                                        <td><?php echo e($submission->user->name); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($submission->vendor->first_name); ?> <?php echo e($submission->vendor->last_name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($submission->teamMember->name ?? '-'); ?></td>
                                    <td><?php echo e($submission->candidate->first_name); ?> <?php echo e($submission->candidate->last_name); ?></td>
                                    <td><?php echo e($submission->job->vendor_amount ?? '-'); ?></td>
                                    <?php if(Auth::user()->id == 1): ?>
                                        <td><?php echo e($submission->job->admin_amount ?? '-'); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($submission->job->created_at); ?></td>
                                    <td><?php echo e($submission->job->completed_at ?? '-'); ?></td>
                                    <td>
                                        <?php if($submission->status == 1): ?>
                                            <div class="badge bg-success">Approved</div>
                                        <?php elseif($submission->status == 2): ?>
                                            <div class="badge bg-warning">Pending</div>
                                        <?php else: ?>
                                            <div class="badge bg-danger">Rejected</div>
                                        <?php endif; ?>
                                    <td>
                                        <div class="dropdown">
                                            <ul class="dropbtn icons">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                            <div id="myDropdown" class="dropdown-content">
                                                
                                                <a href="<?php echo e(route('submission.show', $submission->id)); ?>"><img
                                                        src="<?php echo e(asset('assets/images/edit.png')); ?>">view</a>
                                                
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Submission delete')): ?>
                                                    <a href="<?php echo e(route('submission.delete', $submission->id)); ?>"><img
                                                            src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        <label class="showrow">
                            Show rows
                            <select>
                                <option>5 items</option>
                                <option>10 items</option>
                                <option>20 items</option>
                            </select>
                        </label>
                    </div>
                    <?php echo $__env->make('layout.pagination', ['paginator' => $submissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>

        </div>
    </section>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // $(function() {
        //     $('.toggle-class').change(function() {
        //         var status = $(this).prop('checked') == true ? 1 : 0;
        //         var candidate_id = $(this).data('id');

        //         $.ajax({
        //             type: "GET",
        //             dataType: "json",
        //             url: 'candidate/change-status/' + candidate_id,
        //             data: {
        //                 'status': status,
        //                 'candidate_id': candidate_id
        //             },
        //             success: function(response) {
        //                 console.log(response)
        //             }
        //         });
        //     });
        // });

        $(document).ready(function() {
            $('#reset-btn').on('click',function(){
                console.log('asd');
                $('.form-control').val('');
            })
            // $('#assign-btn').on('click', function() {
            //     // Get the value of the hidden input field
            //     var selectedValue = $('#assignment_id').val();
            //     console.log(selectedValue);
            //     if (selectedValue == 'active') {
            //         $.ajaxSetup({
            //             headers: {
            //                 'X-CSRF-TOKEN': $('input[name="_token"]').val()
            //             }
            //         });
            //         let candidates = [];
            //         $('.candidate-checkbox:checked').each(function() {
            //             candidates.push($(this).val());
            //         });
            //         console.log(candidates);
            //         $.ajax({
            //             method: 'POST',
            //             url: '/candidate/active-status',
            //             data: {
            //                 candidates: candidates,
            //                 _token: "<?php echo e(csrf_token()); ?>"
            //             },
            //             success: function(response) {
            //                 sessionStorage.setItem('success_message', response.message);
            //                 location.reload();
            //             }
            //         });

            //     } else if (selectedValue == 'inactive') {
            //         $.ajaxSetup({
            //             headers: {
            //                 'X-CSRF-TOKEN': $('input[name="_token"]').val()
            //             }
            //         });
            //         let candidates = [];
            //         $('.candidate-checkbox:checked').each(function() {
            //             candidates.push($(this).val());
            //         });

            //         $.ajax({
            //             method: 'POST',
            //             url: '/candidate/inactive-status',
            //             data: {
            //                 candidates: candidates,
            //                 _token: "<?php echo e(csrf_token()); ?>"
            //             },
            //             success: function(response) {
            //                 sessionStorage.setItem('success_message', response.message);
            //                 location.reload();
            //             }
            //         });

            //     } else if (selectedValue == 'job') {
            //         $.ajaxSetup({
            //             headers: {
            //                 'X-CSRF-TOKEN': $('input[name="_token"]').val()
            //             }
            //         });
            //         let candidates = [];
            //         $('.candidate-checkbox:checked').each(function() {
            //             candidates.push($(this).val());
            //         });

            //         $.ajax({
            //             method: 'POST',
            //             url: '/candidate/bulk-delete',
            //             data: {
            //                 candidates: candidates,
            //                 _token: "<?php echo e(csrf_token()); ?>"
            //             },
            //             success: function(response) {
            //                 sessionStorage.setItem('success_message', response.message);
            //                 location.reload();
            //             }
            //         });

            //     }
            // });

            // // Check if there's a success message in sessionStorage
            // const successMessage = sessionStorage.getItem('success_message');

            // // Display the success message if it exists
            // if (successMessage) {
            //     // Set a delay of 500 milliseconds (adjust as needed)
            //     setTimeout(function() {
            //         $('#sucess-asigment-msg').addClass('alert');
            //         $('#sucess-asigment-msg').addClass('alert-success');
            //         $('#sucess-asigment-msg').text(
            //         successMessage); // Use successMessage instead of response.message
            //     }, 500);

            //     // Clear the message after displaying
            //     setTimeout(function() {
            //         $('#sucess-asigment-msg').removeClass('alert');
            //         $('#sucess-asigment-msg').removeClass('alert-success');
            //         $('#sucess-asigment-msg').text('');
            //         sessionStorage.removeItem('success_message');
            //     }, 5000); // Adjust the delay (in milliseconds) as needed
            // }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/submission/index.blade.php ENDPATH**/ ?>