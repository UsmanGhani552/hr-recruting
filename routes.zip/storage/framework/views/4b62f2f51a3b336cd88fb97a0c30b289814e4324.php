<?php
$title = 'Candidate Main';
$keywords = '';
$desc = '';
$pageclass = 'maincadidate';
?>



<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard / Candidate</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="venderdashboar">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="sik-dropdown" id="sik-select">
                        <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            ...
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <li>
                                <span class="dropdown-item" data-value="active">
                                    <img class="" src="<?php echo e(asset('assets/images/bulk1.png')); ?>" alt="btc" />
                                    Active
                                </span>
                            </li>
                            <li>
                                <span class="dropdown-item" data-value="inactive">
                                    <img class="" src="<?php echo e(asset('assets/images/bulk1.png')); ?>" alt="btc" />
                                    Inactive
                                </span>
                            </li>
                            <li>
                                <span class="dropdown-item" data-value="job">
                                    <img class="" src="<?php echo e(asset('assets/images/delete.png')); ?>" alt="btc" />
                                    Delete
                                </span>
                            </li>
                        </ul>
                    </div>
                    <button type="submit" class="cbtn" id="assign-btn">
                        Apply
                    </button>
                </div>
                <div class="col-md-6 text-end">
                    <ul class="vendordash_invite">
                        <li>
                            <a class="cbtn filter_brn" href="javascript:;"><img
                                    src="<?php echo e(asset('assets/images/filter.png')); ?>">Filters</a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate create')): ?>
                            <li>
                                <a class="cbtn" href="<?php echo e(route('candidate.create')); ?>"><img
                                        src="<?php echo e(asset('assets/images/invite.png')); ?>">ADD Candidates</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="filterform">
                <form action="<?php echo e(route('candidate')); ?>" method="get">

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input id="name" type="text" class="form-control" name="name" placeholder="">
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone No</label>
                        <input id="phone" type="tel" class="form-control" name="phone" placeholder="">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" type="email" class="form-control" name="email" placeholder="">
                    </div>

                    <div class="form-group">
                        <label for="position">Position</label>
                        <input id="position" type="tel" class="form-control" name="position" placeholder="">
                    </div>


                    <div class="form-group">
                        <label class="form-group">
                            Vendor
                            <select class="form-controll" name="vendor">
                                <option disabled selected>Select Vendor</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->first_name); ?> <?php echo e($vendor->last_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-group">
                            City*
                            <select class="form-controll" name="city">
                                <option disabled selected>Select city</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-group">
                            State*
                            <select class="form-controll" name="state">
                                <option disabled selected>Selct state</option>
                                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-group">
                            Status
                            <select class="form-controll" name="status">
                                <option disabled selected>Selct state</option>
                                <option value="1">Active</option>
                                <option value="0">In-Active</option>
                            </select>
                        </label>
                    </div>

                    <div class="form_bottons">
                        <button class="cbtn" type="submit">Apply</button>
                        <button class="cbtn btnreset" id="reset-btn" type="reset">Reset</button>
                    </div>

                </form>
            </div>
            <br>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div id="sucess-asigment-msg"> </div>
            <div class="outbox outbox2">
                <table>
                    <thead>
                        <tr>
                            <th>
                                <label for="orderid">
                                    <input type="checkbox" name="" id="orderid">
                                    Order ID
                                </label>
                            </th>
                            <th>Candidate Name</th>
                            <th>Candidate Email</th>
                            <th>Phone Number</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate status')): ?>
                                <th>Status</th>
                            <?php endif; ?>
                            <th>
                                <div class="mydropdown">
                                    <ul class="dropbtn icons">
                                        
                                        Actions
                                    </ul>

                                </div>
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate access')): ?>
                            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <label for="">
                                            <input type="checkbox" name="" value="<?php echo e($candidate->id); ?>"
                                                class="candidate-checkbox">
                                            <?php echo e($candidate->id); ?>

                                        </label>
                                    </td>
                                    <td><?php echo e($candidate->first_name); ?> <?php echo e($candidate->last_name); ?></td>
                                    <td><?php echo e($candidate->email); ?></td>
                                    <td><?php echo e($candidate->phone); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate status')): ?>
                                        <td>
                                            <input data-id="<?php echo e($candidate->id); ?>" class="toggle-class" type="checkbox"
                                                data-onstyle="success" data-offstyle="danger" data-toggle="toggle"
                                                data-on="Active" data-off="InActive" <?php echo e($candidate->status ? 'checked' : ''); ?>>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="dropdown">
                                            <ul class="dropbtn icons">
                                                <li></li>
                                                <li></li>
                                                <li></li>
                                            </ul>
                                            <div id="myDropdown" class="dropdown-content">
                                                <a href="<?php echo e(route('candidate.assignment', $candidate->id)); ?>"><img
                                                        src="<?php echo e(asset('assets/images/eye.png')); ?>">View</a>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate edit')): ?>
                                                    <a href="<?php echo e(route('candidate.edit', $candidate->id)); ?>"><img
                                                            src="<?php echo e(asset('assets/images/edit.png')); ?>">Edit</a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Candidate delete')): ?>
                                                    <a href="<?php echo e(route('candidate.delete', $candidate->id)); ?>"><img
                                                            src="<?php echo e(asset('assets/images/delete.png')); ?>">Delete</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        <label class="showrow">
                            Show rows
                            <select>
                                <option>5 items</option>
                                <option>10 items</option>
                                <option>20 items</option>
                            </select>
                        </label>
                    </div>
                    <?php echo $__env->make('layout.pagination', ['paginator' => $candidates], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>

        </div>
    </section>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $('.toggle-class').change(function() {
                var status = $(this).prop('checked') == true ? 1 : 0;
                var candidate_id = $(this).data('id');

                $.ajax({
                    type: "GET",
                    dataType: "json",
                    url: 'candidate/change-status/' + candidate_id,
                    data: {
                        'status': status,
                        'candidate_id': candidate_id
                    },
                    success: function(response) {
                        console.log(response)
                    }
                });
            });
        });

        $(document).ready(function() {

            $('#assign-btn').on('click', function() {
                // Get the value of the hidden input field
                var selectedValue = $('#assignment_id').val();
                console.log(selectedValue);
                if (selectedValue == 'active') {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('input[name="_token"]').val()
                        }
                    });
                    let candidates = [];
                    $('.candidate-checkbox:checked').each(function() {
                        candidates.push($(this).val());
                    });
                    console.log(candidates);
                    $.ajax({
                        method: 'POST',
                        url: "<?php echo e(url('/candidate/active-status')); ?>",
                        data: {
                            candidates: candidates,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            sessionStorage.setItem('success_message', response.message);
                            location.reload();
                        }
                    });

                } else if (selectedValue == 'inactive') {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('input[name="_token"]').val()
                        }
                    });
                    let candidates = [];
                    $('.candidate-checkbox:checked').each(function() {
                        candidates.push($(this).val());
                    });

                    $.ajax({
                        method: 'POST',
                        url: "<?php echo e(url('/candidate/inactive-status')); ?>",
                        data: {
                            candidates: candidates,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            sessionStorage.setItem('success_message', response.message);
                            location.reload();
                        }
                    });

                } else if (selectedValue == 'job') {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('input[name="_token"]').val()
                        }
                    });
                    let candidates = [];
                    $('.candidate-checkbox:checked').each(function() {
                        candidates.push($(this).val());
                    });

                    $.ajax({
                        method: 'POST',
                        url: "<?php echo e(url('/candidate/bulk-delete')); ?>",
                        data: {
                            candidates: candidates,
                            _token: "<?php echo e(csrf_token()); ?>"
                        },
                        success: function(response) {
                            sessionStorage.setItem('success_message', response.message);
                            location.reload();
                        }
                    });

                }
            });

            $('#reset-btn').on('click',function(){
                console.log('asd');
                $('.form-control').val('');
            })

            // Check if there's a success message in sessionStorage
            const successMessage = sessionStorage.getItem('success_message');

            // Display the success message if it exists
            if (successMessage) {
                // Set a delay of 500 milliseconds (adjust as needed)
                setTimeout(function() {
                    $('#sucess-asigment-msg').addClass('alert');
                    $('#sucess-asigment-msg').addClass('alert-success');
                    $('#sucess-asigment-msg').text(
                        successMessage); // Use successMessage instead of response.message
                }, 500);

                // Clear the message after displaying
                setTimeout(function() {
                    $('#sucess-asigment-msg').removeClass('alert');
                    $('#sucess-asigment-msg').removeClass('alert-success');
                    $('#sucess-asigment-msg').text('');
                    sessionStorage.removeItem('success_message');
                }, 5000); // Adjust the delay (in milliseconds) as needed
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/candidate/index.blade.php ENDPATH**/ ?>