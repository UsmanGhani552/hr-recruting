<?php
$title = 'Add Client';
$keywords = '';
$desc = '';
$pageclass = 'addclient';
?>


<?php $__env->startSection('top_nav'); ?>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="bnr_left">
                        <p>Dashboard / Edit Candidate</p>
                    </div>
                </div>

                <div class="col-md-6 text-end">

                </div>
            </div>
        </div>
    </section>

    <section class="vendor_invite addclient">
        <div class="container">
            <form method="POST" action="<?php echo e(route('candidate.update',$candidate->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <h6>Edit Candidate</h6>
                        <div class="outbox admorebox">


                            <div class="row">
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        First Name
                                        <input type="text" name="first_name" class="form-controll" value="<?php echo e($candidate->first_name); ?>"
                                            placeholder="Enter First Name">
                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Last Name
                                        <input type="text" name="last_name" class="form-controll" value="<?php echo e($candidate->last_name); ?>"
                                            placeholder="Enter Last Name">
                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Phone Number
                                        <input type="tel" name="phone" class="form-controll" value="<?php echo e($candidate->phone); ?>"
                                            placeholder="000-000-000 ">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Email
                                        <input type="email" name="email" class="form-controll" value="<?php echo e($candidate->email); ?>"
                                            placeholder="Email Address">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Method of Communication
                                        <select class="form-controll" name="method_of_communication">
                                            <option <?php echo e($candidate->method_of_communication == 'Phone' ? 'selected' : ''); ?> value="Phone">Phone</option>
                                            <option <?php echo e($candidate->method_of_communication == 'Computer' ? 'selected' : ''); ?> value="Computer">Computer</option>
                                        </select>
                                        <?php $__errorArgs = ['method_of_communication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Highest Education
                                        <select class="form-controll" name="highest_education">
                                            <option <?php echo e($candidate->highest_education == 'Graduate' ? 'selected' : ''); ?> value="Graduate">Graduate</option>
                                            <option <?php echo e($candidate->highest_education == 'High School' ? 'selected' : ''); ?> value="High School">High School</option>
                                        </select>
                                        <?php $__errorArgs = ['highest_education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Years of experience
                                        <input type="text" name="years_of_experience" class="form-controll" value="<?php echo e($candidate->years_of_experience); ?>"
                                            placeholder="Years of experience">
                                    </label>
                                    <?php $__errorArgs = ['years_of_experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Position
                                        <input type="text" value="<?php echo e($candidate->position); ?>" name="position" class="form-controll" placeholder="Position">
                                    </label>
                                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Work Authorization*
                                        <input type="text" value="<?php echo e($candidate->work_authorization); ?>" name="work_authorization" class="form-controll"
                                            placeholder="Work Authorization">
                                    </label>
                                    <?php $__errorArgs = ['work_authorization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Expected Pay Rate
                                        <input type="text" value="<?php echo e($candidate->expected_pay_rate); ?>" name="expected_pay_rate" class="form-controll"
                                            placeholder="Expected Pay Rate">
                                    </label>
                                    <?php $__errorArgs = ['expected_pay_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Availability to Start
                                        <select class="form-controll" name="availability_to_start">
                                            <option <?php echo e($candidate->availability_to_start == 'January' ? 'selected' : ''); ?> value="January">January</option>
                                            <option <?php echo e($candidate->availability_to_start == 'March' ? 'selected' : ''); ?> value="March">March</option>
                                        </select>
                                        <?php $__errorArgs = ['availability_to_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Availability to Interview
                                        <select class="form-controll" name="availability_to_interview">
                                            <option <?php echo e($candidate->availability_to_interview == 'January' ? 'selected' : ''); ?> value="January">January</option>
                                            <option <?php echo e($candidate->availability_to_interview == 'March' ? 'selected' : ''); ?> value="March">March</option>
                                        </select>
                                        <?php $__errorArgs = ['availability_to_interview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Country
                                        <select class="form-controll" name="country">
                                            <option value="<?php echo e($candidate->country); ?>">United States</option>
                                        </select>
                                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        State
                                        <select class="form-controll select2" name="state">
                                            <option></option>
                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value=<?php echo e($state->id); ?> <?php echo e($candidate->state_id == $state->id ? 'selected' : ''); ?> ><?php echo e($state->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        City
                                        <select class="form-controll select2" name="city">
                                            <option></option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value=<?php echo e($city->id); ?> <?php echo e($candidate->availability_to_interview == 'January' ? 'selected' : ''); ?> value="January"><?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Postal Code
                                        <input type="text" name="postal_code" class="form-controll" value="<?php echo e($candidate->postal_code); ?>"
                                            placeholder="Postal Code">
                                    </label>
                                    <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Status
                                        <select class="form-controll" name="status">
                                            <option value="1" <?php echo e($candidate->availability_to_interview == 'January' ? 'selected' : ''); ?> value="January">Active</option>
                                            <option value="0" <?php echo e($candidate->availability_to_interview == 'January' ? 'selected' : ''); ?> value="January">InActive</option>
                                        </select>
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                </div>

                                <div class="col-lg-2 col-md-4">
                                    <label class="form-group">
                                        Vendor
                                        <select class="form-controll" name="vendor">
                                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($vendor->id); ?>" <?php echo e($candidate->availability_to_interview == 'January' ? 'selected' : ''); ?> value="January"><?php echo e($vendor->first_name); ?> <?php echo e($vendor->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>
                                </div>

                                <div class="col-lg-2 col-md-4">
                                    <div class="file-hidden-list"></div>
                                    <div class="new_job_fileupload">

                                        <div class="file-list">
                                        </div>

                                        <label class="form-group">
                                            <div class="uploadoc">
                                                
                                                <input type="file" name="resume">
                                                
                                            </div>
                                        </label>

                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12">
                                    <label class="form-group">
                                        Additional Notes (Optional)
                                        <textarea class="form-controll"  placeholder="Message" name="notes"><?php echo e($candidate->notes); ?></textarea>
                                    </label>
                                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <div class="form-group">
                                        <input type="submit" name="" value="Submit">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </form>
        </div>
    </section>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\hr-recruting\resources\views/candidate/edit.blade.php ENDPATH**/ ?>